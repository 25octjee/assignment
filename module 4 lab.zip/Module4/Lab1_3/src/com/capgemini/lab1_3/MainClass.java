package com.capgemini.lab1_3;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class MainClass {

	public static void main(String[] args) {
		Resource rsc = new ClassPathResource("beans.xml");
		BeanFactory factory = new XmlBeanFactory(rsc);
		SBU sBU = (SBU) factory.getBean("sbu");
		System.out.println("SBU Details\n---------------------");
		System.out.println(sBU.toString());
		
	}

}
