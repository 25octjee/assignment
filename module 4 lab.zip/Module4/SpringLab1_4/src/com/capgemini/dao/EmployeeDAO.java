/**
 * 
 */
package com.capgemini.dao;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.bean.Employee;

/**
 * @author 
 *
 */
public class EmployeeDAO implements IEmployeeDAO {

	private List<Employee> empList;

	public List<Employee> getEmpList() {
		return empList;
	}

	public void setEmpList(List<Employee> empList) {
		this.empList = empList;
	}

	public EmployeeDAO() {
		super();
		empList = new ArrayList<>();
		Employee emp1 = new Employee();
		emp1.setEmpId(1001);
		emp1.setEmpName("Priyanka");
		emp1.setSalary(100000);
		empList.add(emp1);
		Employee emp2 = new Employee();
		emp2.setEmpId(1002);
		emp2.setEmpName("Piya");
		emp2.setSalary(200000);
		empList.add(emp2);
		Employee emp3 = new Employee();
		emp3.setEmpId(1003);
		emp3.setEmpName("Sonal");
		emp3.setSalary(45000);
		empList.add(emp3);
	}

	@Override
	public Employee getEmployeeBean(int empId) {
		for (Employee employee : this.getEmpList()) {
			if (employee.getEmpId() == empId)
				return employee;
		}
		return null;
	}

}
