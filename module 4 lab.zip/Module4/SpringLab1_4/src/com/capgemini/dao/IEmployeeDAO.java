/**
 * 
 */
package com.capgemini.dao;

import com.capgemini.bean.Employee;

/**
 * @author 
 *
 */
public interface IEmployeeDAO {
	public Employee getEmployeeBean(int empId);
}
