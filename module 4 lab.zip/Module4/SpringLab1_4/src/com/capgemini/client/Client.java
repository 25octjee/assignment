/**
 * 
 */
package com.capgemini.client;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.bean.Employee;
import com.capgemini.service.EmployeeService;
import com.capgemini.service.IEmployeeService;

/**
 * @author 
 *
 */
public class Client {

	public static void main(String[] args) {
		IEmployeeService employeeService;
		int empId = 0;
		Employee employee = null;
		Scanner input = new Scanner(System.in);

		ApplicationContext applicationContext = new ClassPathXmlApplicationContext(
				"bean.xml");

		employeeService = (EmployeeService) applicationContext
				.getBean("employeeService");

		System.out.println("EmployeeID :");
		empId = input.nextInt();

		employee = employeeService.getEmployeeBean(empId);
		if (employee != null) {
			System.out.println(employee);
		}

	}

}
