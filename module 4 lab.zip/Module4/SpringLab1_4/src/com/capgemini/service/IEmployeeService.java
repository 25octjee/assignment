/**
 * 
 */
package com.capgemini.service;

import com.capgemini.bean.Employee;

/**
 * @author
 *
 */
public interface IEmployeeService {

	public Employee getEmployeeBean(int empId);

}
