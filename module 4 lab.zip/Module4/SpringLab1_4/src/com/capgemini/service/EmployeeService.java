/**
 * 
 */
package com.capgemini.service;

import com.capgemini.bean.Employee;
import com.capgemini.dao.EmployeeDAO;
import com.capgemini.dao.IEmployeeDAO;

/**
 * @author 
 *
 */
public class EmployeeService implements IEmployeeService {

	private IEmployeeDAO employeeDAO;

	public IEmployeeDAO getEmployeeDAO() {
		return employeeDAO;
	}

	public void setEmployeeDAO(IEmployeeDAO employeeDAO) {
		this.employeeDAO = employeeDAO;
	}

	@Override
	public Employee getEmployeeBean(int empId) {

		return employeeDAO.getEmployeeBean(empId);
	}

}
