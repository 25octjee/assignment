/**
 * 
 */
package com.cg.ioc;

/**
 * @author 
 *
 */
public class Employee {

	private int employeeId;
	private String employeeName;
	private double salary;
	private String businessUnit;
	private int age;
	private SBU sbu;

	public SBU getSbu() {
		return sbu;
	}



	public void setSbu(SBU sbu) {
		this.sbu = sbu;
	}



	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	public int getEmployeeId() {
		return employeeId;
	}



	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}



	public String getEmployeeName() {
		return employeeName;
	}



	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}



	public double getSalary() {
		return salary;
	}



	public void setSalary(double salary) {
		this.salary = salary;
	}



	public String getBusinessUnit() {
		return businessUnit;
	}



	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}



	public int getAge() {
		return age;
	}

public SBU getSbuDetails()
{
	return sbu;
	}

	public void setAge(int age) {
		this.age = age;
	}
	
	public void displayInfo() {
		System.out.println("Employee Details");
		System.out.println("-------------------------");
		System.out.println("Employee [empAge="+age+", empId="+employeeId+", empName="+employeeName+", empSalary="+salary);
		//System.out.println(sbu.toString());
		System.out.println(getSbuDetails());
	}
	
}
